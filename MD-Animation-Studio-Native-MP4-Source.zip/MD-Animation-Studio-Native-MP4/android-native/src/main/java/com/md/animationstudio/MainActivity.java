package com.md.animationstudio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(android.os.Bundle savedInstanceState) {
        registerPlugin(NativeMovieExporterPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
