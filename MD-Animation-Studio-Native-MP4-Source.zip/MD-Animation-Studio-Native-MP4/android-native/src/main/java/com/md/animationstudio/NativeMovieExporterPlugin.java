package com.md.animationstudio;

import android.content.ContentValues;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "NativeMovieExporter")
public class NativeMovieExporterPlugin extends Plugin {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private ExportSession session;

    @PluginMethod
    public void startExport(PluginCall call) {
        worker.execute(() -> {
            try {
                int width = even(call.getInt("width", 720));
                int height = even(call.getInt("height", 1280));
                int fps = call.getInt("fps", 30);
                int sampleRate = call.getInt("sampleRate", 44100);
                String displayName = call.getString("displayName", "MD-Animation-Movie.mp4");
                File out = new File(getContext().getCacheDir(), "md_movie_" + System.currentTimeMillis() + ".mp4");
                if (!displayName.toLowerCase(Locale.ROOT).endsWith(".mp4")) displayName += ".mp4";
                session = new ExportSession(out, width, height, fps, sampleRate, displayName);
                session.start();
                JSObject ret = new JSObject();
                ret.put("started", true);
                ret.put("width", width);
                ret.put("height", height);
                ret.put("displayName", displayName);
                call.resolve(ret);
            } catch (Exception e) {
                call.reject("Native MP4 encoder start failed: " + e.getMessage(), e);
            }
        });
    }

    @PluginMethod
    public void addFrame(PluginCall call) {
        worker.execute(() -> {
            try {
                if (session == null) throw new IllegalStateException("Export session not started");
                String jpg = call.getString("jpegBase64");
                String pcm = call.getString("pcmBase64");
                session.addFrame(Base64.decode(jpg, Base64.DEFAULT), pcm == null ? new byte[0] : Base64.decode(pcm, Base64.DEFAULT));
                call.resolve();
            } catch (Exception e) {
                call.reject("Frame encoding failed: " + e.getMessage(), e);
            }
        });
    }

    @PluginMethod
    public void finishExport(PluginCall call) {
        worker.execute(() -> {
            try {
                if (session == null) throw new IllegalStateException("No active export");
                File mp4 = session.finish();
                String displayName = session.displayName;
                session = null;
                Uri saved = copyToMovies(mp4, displayName);
                JSObject ret = new JSObject();
                ret.put("uri", saved.toString());
                ret.put("displayName", displayName);
                ret.put("saved", true);
                call.resolve(ret);
            } catch (Exception e) {
                call.reject("MP4 finalization failed: " + e.getMessage(), e);
            }
        });
    }

    @PluginMethod
    public void cancelExport(PluginCall call) {
        worker.execute(() -> {
            try { if (session != null) session.abort(); } catch (Exception ignored) {}
            session = null;
            call.resolve();
        });
    }

    @PluginMethod
    public void synthesizeDialogue(PluginCall call) {
        String text = call.getString("text", "").trim();
        if (text.isEmpty()) { call.reject("Dialogue text is empty"); return; }
        String language = call.getString("language", "hi-IN");
        getActivity().runOnUiThread(() -> {
            final File wav = new File(getContext().getCacheDir(), "md_tts_" + System.currentTimeMillis() + ".wav");
            final String utteranceId = "mdtts_" + System.currentTimeMillis();
            final TextToSpeech[] holder = new TextToSpeech[1];
            holder[0] = new TextToSpeech(getContext(), status -> {
                if (status != TextToSpeech.SUCCESS) {
                    call.reject("Android Text-to-Speech initialization failed"); return;
                }
                TextToSpeech tts = holder[0];
                int langStatus = tts.setLanguage(Locale.forLanguageTag(language));
                if (langStatus == TextToSpeech.LANG_MISSING_DATA || langStatus == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Locale fallback = Locale.getDefault();
                    int fallbackStatus = tts.setLanguage(fallback);
                    if (fallbackStatus == TextToSpeech.LANG_MISSING_DATA || fallbackStatus == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts.shutdown(); call.reject("Hindi TTS voice data is not installed on this device"); return;
                    }
                }
                tts.setSpeechRate(0.94f);
                tts.setPitch(1.0f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) {}
                    @Override public void onError(String id) { tts.shutdown(); call.reject("TTS synthesis failed"); }
                    @Override public void onDone(String id) {
                        try {
                            byte[] bytes = readAll(wav);
                            JSObject ret = new JSObject();
                            ret.put("wavBase64", Base64.encodeToString(bytes, Base64.NO_WRAP));
                            ret.put("language", language);
                            call.resolve(ret);
                        } catch (Exception e) { call.reject("Could not read generated dialogue audio", e); }
                        finally { tts.shutdown(); wav.delete(); }
                    }
                });
                Bundle params = new Bundle();
                int result = tts.synthesizeToFile(text, params, wav, utteranceId);
                if (result == TextToSpeech.ERROR) { tts.shutdown(); call.reject("TTS could not create audio file"); }
            });
        });
    }

    private Uri copyToMovies(File source, String displayName) throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/MD Animation Studio");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
        }
        Uri uri = getContext().getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Could not create gallery entry");
        try (FileInputStream in = new FileInputStream(source);
             OutputStream out = getContext().getContentResolver().openOutputStream(uri)) {
            byte[] buffer = new byte[1024 * 128]; int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues done = new ContentValues(); done.put(MediaStore.Video.Media.IS_PENDING, 0);
            getContext().getContentResolver().update(uri, done, null, null);
        }
        source.delete();
        return uri;
    }

    private static int even(int n) { return n % 2 == 0 ? n : n - 1; }
    private static byte[] readAll(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) out.write(b, 0, n); return out.toByteArray();
        }
    }

    private static class Sample {
        final byte[] data; final MediaCodec.BufferInfo info;
        Sample(byte[] d, MediaCodec.BufferInfo i) { data=d; info=new MediaCodec.BufferInfo(); info.set(0,d.length,i.presentationTimeUs,i.flags); }
    }

    private class ExportSession {
        final File output; final int width,height,fps,sampleRate; final String displayName;
        MediaCodec video,audio; MediaMuxer muxer;
        int videoTrack=-1,audioTrack=-1; boolean muxerStarted=false, videoEos=false,audioEos=false;
        long frameIndex=0,audioSamples=0;
        final List<Sample> pendingVideo=new ArrayList<>(),pendingAudio=new ArrayList<>();
        final MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
        int colorFormat;

        ExportSession(File out,int w,int h,int f,int sr,String name){output=out;width=w;height=h;fps=f;sampleRate=sr;displayName=name;}
        void start() throws Exception {
            MediaFormat vf=MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,width,height);
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar);
            vf.setInteger(MediaFormat.KEY_BIT_RATE, Math.max(1800000,width*height*4));
            vf.setInteger(MediaFormat.KEY_FRAME_RATE,fps);
            vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,2);
            video=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            MediaCodecInfo.CodecCapabilities caps=video.getCodecInfo().getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC);
            colorFormat=chooseColor(caps);
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT,colorFormat);
            video.configure(vf,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);video.start();

            MediaFormat af=MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC,sampleRate,1);
            af.setInteger(MediaFormat.KEY_AAC_PROFILE,MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            af.setInteger(MediaFormat.KEY_BIT_RATE,128000);
            af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE,16384);
            audio=MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            audio.configure(af,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);audio.start();
            muxer=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        }
        int chooseColor(MediaCodecInfo.CodecCapabilities caps){
            for(int c:caps.colorFormats)if(c==MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar)return c;
            for(int c:caps.colorFormats)if(c==MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)return c;
            return MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar;
        }
        void addFrame(byte[] jpeg,byte[] pcm) throws Exception {
            Bitmap raw=BitmapFactory.decodeByteArray(jpeg,0,jpeg.length);
            if(raw==null)throw new Exception("JPEG frame decode failed");
            Bitmap bmp=Bitmap.createScaledBitmap(raw,width,height,true);if(raw!=bmp)raw.recycle();
            byte[] yuv=bitmapToYuv(bmp,colorFormat==MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar);bmp.recycle();
            int in=video.dequeueInputBuffer(10000);
            if(in<0)throw new Exception("Video encoder input buffer unavailable");
            ByteBuffer ib=video.getInputBuffer(in);ib.clear();ib.put(yuv);
            long pts=frameIndex*1000000L/fps;
            video.queueInputBuffer(in,0,yuv.length,pts,0);frameIndex++;
            feedAudio(pcm);
            drain(video,false,true);drain(audio,false,false);
        }
        void feedAudio(byte[] pcm) throws Exception {
            if(pcm.length==0)return;
            int off=0;
            while(off<pcm.length){
                int in=audio.dequeueInputBuffer(10000);
                if(in<0)throw new Exception("Audio encoder input buffer unavailable");
                ByteBuffer ib=audio.getInputBuffer(in);ib.clear();int n=Math.min(ib.remaining(),pcm.length-off);
                n-=n%2;ib.put(pcm,off,n);
                long pts=audioSamples*1000000L/sampleRate;
                audio.queueInputBuffer(in,0,n,pts,0);audioSamples+=n/2;off+=n;
                drain(audio,false,false);
            }
        }
        void drain(MediaCodec codec,boolean eos,boolean isVideo) throws Exception {
            while(true){
                int out=codec.dequeueOutputBuffer(info,0);
                if(out==MediaCodec.INFO_TRY_AGAIN_LATER)break;
                if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){
                    MediaFormat fmt=codec.getOutputFormat();
                    if(isVideo)videoTrack=muxer.addTrack(fmt);else audioTrack=muxer.addTrack(fmt);
                    maybeStart();continue;
                }
                if(out>=0){
                    ByteBuffer ob=codec.getOutputBuffer(out);
                    if((info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)!=0){info.size=0;}
                    if(info.size>0){
                        byte[] bytes=new byte[info.size];ob.position(info.offset);ob.limit(info.offset+info.size);ob.get(bytes);
                        MediaCodec.BufferInfo cp=new MediaCodec.BufferInfo();cp.set(0,bytes.length,info.presentationTimeUs,info.flags);
                        Sample sample=new Sample(bytes,cp);
                        if(muxerStarted)writeSample(sample,isVideo);else (isVideo?pendingVideo:pendingAudio).add(sample);
                    }
                    boolean end=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;
                    codec.releaseOutputBuffer(out,false);
                    if(end){if(isVideo)videoEos=true;else audioEos=true;break;}
                }
            }
            maybeStart();
        }
        void maybeStart() throws Exception {
            if(!muxerStarted&&videoTrack>=0&&audioTrack>=0){
                muxer.start();muxerStarted=true;
                for(Sample s:pendingVideo)writeSample(s,true);pendingVideo.clear();
                for(Sample s:pendingAudio)writeSample(s,false);pendingAudio.clear();
            }
        }
        void writeSample(Sample s,boolean isVideo){
            ByteBuffer b=ByteBuffer.wrap(s.data);muxer.writeSampleData(isVideo?videoTrack:audioTrack,b,s.info);
        }
        File finish() throws Exception {
            queueEos(video, frameIndex*1000000L/fps);
            queueEos(audio, audioSamples*1000000L/sampleRate);
            int guard=0;while((!videoEos||!audioEos)&&guard++<10000){drain(video,false,true);drain(audio,false,false);Thread.sleep(2);}
            if(!videoEos||!audioEos)throw new Exception("Encoder did not finish its output stream");
            if(!muxerStarted)throw new Exception("MP4 muxer did not receive encoder formats");
            muxer.stop();muxer.release();video.stop();video.release();audio.stop();audio.release();
            return output;
        }
        void queueEos(MediaCodec codec,long pts) throws Exception {
            int input=-1;
            for(int tries=0;input<0&&tries<100;tries++){input=codec.dequeueInputBuffer(10000);if(input<0)Thread.sleep(5);}
            if(input<0)throw new Exception("Encoder EOS buffer unavailable");
            codec.queueInputBuffer(input,0,0,pts,MediaCodec.BUFFER_FLAG_END_OF_STREAM);
        }
        void abort(){try{if(video!=null){video.stop();video.release();}}catch(Exception ignored){}try{if(audio!=null){audio.stop();audio.release();}}catch(Exception ignored){}try{if(muxer!=null){if(muxerStarted)muxer.stop();muxer.release();}}catch(Exception ignored){}output.delete();}
        byte[] bitmapToYuv(Bitmap bmp,boolean semi){
            int w=width,h=height;int[] argb=new int[w*h];bmp.getPixels(argb,0,w,0,0,w,h);
            int ySize=w*h;byte[] out=new byte[ySize+ySize/2];int yIndex=0,uvIndex=ySize;
            for(int j=0;j<h;j++)for(int i=0;i<w;i++){
                int c=argb[j*w+i],r=Color.red(c),g=Color.green(c),b=Color.blue(c);
                int y=((66*r+129*g+25*b+128)>>8)+16;
                out[yIndex++]=(byte)Math.max(0,Math.min(255,y));
            }
            if(semi){
                for(int j=0;j<h;j+=2)for(int i=0;i<w;i+=2){
                    int r=0,g=0,b=0;for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++){int c=argb[(j+dy)*w+i+dx];r+=Color.red(c);g+=Color.green(c);b+=Color.blue(c);}
                    r/=4;g/=4;b/=4;int u=((-38*r-74*g+112*b+128)>>8)+128;int v=((112*r-94*g-18*b+128)>>8)+128;
                    out[uvIndex++]=(byte)Math.max(0,Math.min(255,u));out[uvIndex++]=(byte)Math.max(0,Math.min(255,v));
                }
            }else{
                int uStart=ySize,vStart=ySize+ySize/4,ui=uStart,vi=vStart;
                for(int j=0;j<h;j+=2)for(int i=0;i<w;i+=2){
                    int r=0,g=0,b=0;for(int dy=0;dy<2;dy++)for(int dx=0;dx<2;dx++){int c=argb[(j+dy)*w+i+dx];r+=Color.red(c);g+=Color.green(c);b+=Color.blue(c);}
                    r/=4;g/=4;b/=4;int u=((-38*r-74*g+112*b+128)>>8)+128;int v=((112*r-94*g-18*b+128)>>8)+128;
                    out[ui++]=(byte)Math.max(0,Math.min(255,u));out[vi++]=(byte)Math.max(0,Math.min(255,v));
                }
            }
            return out;
        }
    }

    @Override
    public void handleOnDestroy() {
        worker.shutdown();
        super.handleOnDestroy();
    }
}
