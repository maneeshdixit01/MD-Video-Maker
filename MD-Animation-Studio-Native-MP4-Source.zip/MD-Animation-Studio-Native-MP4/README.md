# MD Animation Studio — Native MP4 Edition

Android-first coding-based 3D cartoon movie maker. No AI API and no cloud rendering.

## Features
- Three.js 3D viewport, orbit/pan/zoom camera controls
- Procedural lion, rabbit and human starter characters
- Walk, run, jump, wave, talk and roar motion
- Scene timeline, rule-based Hindi story-to-scenes helper
- Scene dialogue field
- Native Android Text-to-Speech synthesis to WAV (uses installed device voice data)
- Lip-sync mouth movement driven by dialogue audio amplitude
- Import local audio files as background music / recorded voice tracks
- Separate dialogue and music volume controls
- Native Android H.264 video encoding with `MediaCodec`
- Native AAC audio encoding and MP4 muxing with `MediaMuxer`
- Saves completed MP4 to Android MediaStore under Movies/MD Animation Studio
- GLB/GLTF model import
- Local project autosave and JSON backup/restore

## Build with GitHub Actions
1. Extract this ZIP.
2. Upload all contents of `MD-Animation-Studio-Native-MP4` to the root of your GitHub repository.
3. Keep `.github/workflows/build.yml` at exactly that path.
4. Push to `main` or run the workflow manually.
5. Download the `MD-Animation-Studio-debug-apk` artifact.

The workflow creates the Capacitor Android project, copies the native Java plugin and MainActivity registration, and builds the debug APK.

## Important technical notes
- MP4 rendering currently sends rendered JPEG frames and mixed PCM audio chunks from the WebView to the native Android encoder. The final video is H.264 MP4 with AAC audio, not WebM.
- The app uses 30 fps and currently offers 480p/720p output. High-resolution and long-duration exports require substantial device memory, CPU and storage; test short scenes first.
- Native Text-to-Speech uses Android's installed TTS voice data. Hindi offline speech requires a Hindi voice pack installed and downloaded on the phone. Some TTS engines may require internet for missing voices.
- Imported audio is mixed locally in the app. Audio files are kept in the current app session; add them again after restarting the app. The scene dialogue text is saved in the project.
- Lip-sync is amplitude-based mouth opening/closing, not phoneme-level facial animation.
- Imported GLB animation clips are not yet retargeted to the built-in action system.
- The procedural characters are starter models, not professional studio-grade character rigs.
- Verify the native encoder on the target Android device. Codec support varies by device manufacturer.

## Stack
- Three.js + Vite
- Capacitor 6
- Android `MediaCodec` (H.264 + AAC)
- Android `MediaMuxer` (MP4)
- Android `TextToSpeech`
- Android `MediaStore`
