import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { registerPlugin } from '@capacitor/core';
const NativeMovieExporter = registerPlugin('NativeMovieExporter');

const $ = (id) => document.getElementById(id);
const esc = (s='') => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const toast = (msg) => { const t=$('toast'); t.textContent=msg; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),2300); };

$('app').innerHTML = `
<header class="topbar">
  <div class="brandmark">MD<span>3D</span></div>
  <div class="brandcopy"><b>MD Animation Studio</b><small>3D CARTOON MOVIE MAKER · OFFLINE ENGINE</small></div>
  <button class="iconbtn" id="helpBtn" title="Help">?</button>
</header>
<main>
  <section class="welcome">
    <div><span class="eyebrow">YOUR PERSONAL CARTOON FILM STUDIO</span><h1>अपनी कहानी को <em>3D मूवी</em> बनाइए</h1>
    <p>बिना AI API · 3D कैरेक्टर · सीन टाइमलाइन · कैमरा कंट्रोल</p></div>
    <div class="statuspill"><i></i> OFFLINE READY</div>
  </section>

  <section class="studio-grid">
    <div class="viewport-card">
      <div class="viewport-head"><div><b>3D VIEWPORT</b><small id="viewStatus">सीन 1 · लाइव प्रीव्यू</small></div>
        <div class="viewtools"><button id="cameraHome">⌂</button><button id="cameraFront">FRONT</button><button id="cameraWide">WIDE</button></div>
      </div>
      <div id="viewport"><div class="loading">3D स्टूडियो लोड हो रहा है…</div></div>
      <div class="viewport-foot"><span>एक उंगली: कैमरा घुमाएँ · दो उंगली: ज़ूम/पैन</span><span id="fpsLabel">3D ENGINE</span></div>
    </div>

    <aside class="side-stack">
      <section class="panel">
        <div class="panel-title"><div><span class="step">01</span><h2>मूवी प्रोजेक्ट</h2></div><span class="tag">PROJECT</span></div>
        <label>मूवी का नाम</label><input id="movieName" value="जंगल का नया दोस्त" maxlength="80">
        <div class="button-row"><button class="primary" id="saveProject">प्रोजेक्ट सेव</button><button id="backupBtn">JSON बैकअप</button></div>
        <button class="subtle full" id="restoreBtn">बैकअप से प्रोजेक्ट खोलें</button><input id="restoreFile" type="file" accept=".json" hidden>
      </section>
      <section class="panel">
        <div class="panel-title"><div><span class="step">02</span><h2>कहानी से सीन</h2></div><span class="tag">RULE BASED</span></div>
        <textarea id="storyInput" rows="4" placeholder="एक जंगल में शेर रहता था। एक दिन खरगोश वहाँ आया। दोनों दोस्त बन गए।"></textarea>
        <button class="primary full" id="storyBuild">कहानी को सीन में बदलें</button>
        <p class="micro">कहानी के वाक्यों और हिंदी कीवर्ड से शुरुआती सीन बनते हैं। यह AI नहीं है; हर सीन बाद में एडिट किया जा सकता है।</p>
      </section>
    </aside>
  </section>

  <section class="panel timeline-panel">
    <div class="panel-title"><div><span class="step">03</span><h2>मूवी टाइमलाइन</h2></div>
      <div class="timeline-actions"><button id="addScene">＋ नया सीन</button><button class="primary" id="playMovie">▶ पूरी मूवी चलाएँ</button></div>
    </div>
    <div class="timeline-strip" id="timeline"></div>
    <div class="timeline-summary"><span id="sceneSummary">1 सीन</span><span id="totalDuration">कुल अवधि: 6 सेकंड</span></div>
  </section>

  <section class="editor-grid">
    <section class="panel">
      <div class="panel-title"><div><span class="step">04</span><h2>कैरेक्टर लाइब्रेरी</h2></div><span class="tag">3D CHARACTERS</span></div>
      <div class="character-grid">
        <button class="character active" data-actor="lion"><span>🦁</span><b>शेर</b><small>3D procedural</small></button>
        <button class="character" data-actor="rabbit"><span>🐰</span><b>खरगोश</b><small>3D procedural</small></button>
        <button class="character" data-actor="human"><span>🧍</span><b>इंसान</b><small>3D procedural</small></button>
        <button class="character import-card" id="importModel"><span>＋</span><b>मॉडल इम्पोर्ट</b><small>GLB / GLTF</small></button>
      </div>
      <input id="modelFile" type="file" accept=".glb,.gltf" hidden>
      <p class="micro">अपने Blender या अन्य 3D सॉफ्टवेयर में बने GLB/GLTF मॉडल भी जोड़ें। इम्पोर्टेड मॉडल की अपनी animation clips अभी अलग से retarget नहीं होतीं।</p>
    </section>

    <section class="panel">
      <div class="panel-title"><div><span class="step">05</span><h2>सीन सेटिंग</h2></div><span class="tag" id="selectedSceneTag">SCENE 1</span></div>
      <label>सीन का नाम</label><input id="sceneName" maxlength="60" value="शुरुआत">
      <label>सीन में क्या हो रहा है?</label><textarea id="sceneDescription" rows="2" placeholder="शेर जंगल में धीरे-धीरे चलता है"></textarea>
      <div class="form-two">
        <div><label>कैरेक्टर</label><select id="actorSelect"><option value="lion">शेर</option><option value="rabbit">खरगोश</option><option value="human">इंसान</option><option value="custom">इम्पोर्टेड मॉडल</option></select></div>
        <div><label>एक्शन</label><select id="actionSelect">
          <option value="idle">साँस लेना / खड़ा</option><option value="walk">चलना</option><option value="run">दौड़ना</option><option value="jump">कूदना</option><option value="wave">हाथ हिलाना</option><option value="talk">बात करना</option><option value="roar">दहाड़ना</option>
        </select></div>
      </div>
      <div class="form-two">
        <div><label>अवधि (सेकंड)</label><input id="durationInput" type="number" min="1" max="60" value="6"></div>
        <div><label>माहौल</label><select id="environmentSelect"><option value="forest">हरा-भरा जंगल</option><option value="meadow">खुला मैदान</option><option value="night">रात का दृश्य</option></select></div>
      </div>
      <div class="form-two">
        <div><label>कैमरा एंगल</label><select id="cameraSelect"><option value="wide">वाइड शॉट</option><option value="medium">मीडियम शॉट</option><option value="close">क्लोज़-अप</option><option value="low">लो एंगल</option></select></div>
        <div><label>कैमरा मूवमेंट</label><select id="cameraMove"><option value="static">स्थिर</option><option value="pan">धीमा पैन</option><option value="orbit">ऑर्बिट</option></select></div>
      </div>
      <button class="primary full" id="applyScene">सीन में बदलाव लागू करें</button>
      <div class="button-row"><button id="duplicateScene">सीन कॉपी</button><button class="danger" id="deleteScene">सीन हटाएँ</button></div>
    </section>
  </section>

  <section class="export-grid">
    <section class="panel">
      <div class="panel-title"><div><span class="step">06</span><h2>डायलॉग और आवाज़</h2></div><span class="tag">NATIVE TTS</span></div>
      <label>चुने हुए सीन का संवाद</label>
      <textarea id="dialogueInput" rows="3" placeholder="जैसे: नमस्ते दोस्तों, आज हम जंगल की सैर करेंगे।"></textarea>
      <div class="form-two">
        <div><label>डायलॉग वॉल्यूम</label><input id="dialogueVolume" type="range" min="0" max="1.5" step="0.05" value="1"></div>
        <div><label>म्यूजिक वॉल्यूम</label><input id="musicVolume" type="range" min="0" max="1.5" step="0.05" value="0.35"></div>
      </div>
      <div class="button-row"><button class="primary" id="saveDialogue">डायलॉग सेव</button><button id="previewTts">आवाज़ सुनें</button></div>
      <label>बैकग्राउंड म्यूजिक / रिकॉर्डेड आवाज़ जोड़ें</label>
      <input id="audioFileInput" type="file" accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg" multiple>
      <div id="audioTrackList" class="audio-track-list"><small>अभी कोई ऑडियो ट्रैक नहीं जोड़ा गया।</small></div>
      <p class="micro">डायलॉग Android Native Text-to-Speech से बनेगा। ऑडियो फाइलें डिवाइस से इम्पोर्ट होंगी। TTS की ऑफलाइन भाषा उपलब्धता फोन के इंस्टॉल किए गए voice pack पर निर्भर है।</p>
    </section>
    <section class="panel">
      <div class="panel-title"><div><span class="step">07</span><h2>Native MP4 एक्सपोर्ट</h2></div><span class="tag">H.264 + AAC</span></div>
      <div class="form-two">
        <div><label>वीडियो फॉर्मेट</label><select id="aspectSelect"><option value="portrait">रील / Shorts · 9:16</option><option value="landscape">YouTube · 16:9</option><option value="square">Square · 1:1</option></select></div>
        <div><label>रेंडर क्वालिटी</label><select id="qualitySelect"><option value="720">HD · 720p</option><option value="480">480p · हल्का</option></select></div>
      </div>
      <button class="primary full export-button" id="exportBtn">● Native MP4 बनाएं और गैलरी में सेव करें</button>
      <div id="exportProgress" class="progress-wrap" hidden><div class="progress-track"><i id="progressBar"></i></div><small id="progressText">तैयारी…</small></div>
      <a id="videoDownload" class="download-link" hidden></a>
      <p class="micro">Native Android MediaCodec से H.264 वीडियो, AAC ऑडियो और MediaMuxer से MP4। Android MediaStore के जरिए Movies/MD Animation Studio में सेव होगा। लंबी फिल्म रेंडर होने में समय लगेगा।</p>
    </section>
  </section>
  <section class="panel">
    <div class="panel-title"><div><span class="step">08</span><h2>मूवी इंजन</h2></div><span class="tag">OFFLINE FIRST</span></div>
    <div class="feature-grid">
      <span>✓ Android Native H.264 MP4</span><span>✓ AAC डायलॉग + म्यूजिक</span>
      <span>✓ Native Text-to-Speech</span><span>✓ ऑडियो-आधारित लिप-सिंक</span>
      <span>✓ Three.js 3D सीन और टाइमलाइन</span><span>✓ AI API की जरूरत नहीं</span>
    </div>
    <div class="note">ऑफलाइन TTS के लिए फोन में हिंदी voice data डाउनलोड होना चाहिए। कुछ डिवाइस पर भाषा पैक उपलब्ध न होने पर TTS इंटरनेट माँग सकता है।</div>
  </section>
</main>
<footer>MD ANIMATION STUDIO · BUILT WITH THREE.JS + CAPACITOR</footer>
<div id="toast"></div>`;

const defaultScenes = [{id:uid(),name:'शुरुआत',actor:'lion',action:'idle',duration:6,description:'शेर हरे-भरे जंगल में खड़ा है',environment:'forest',camera:'wide',cameraMove:'static'}];
function uid(){return 's'+Math.random().toString(36).slice(2,10);}
let scenes = loadProject()?.scenes || defaultScenes;
let current = 0, actorObject = null, importedObject = null, importedUrl = null;
let moviePlaying = false, recording = false, animationClock = 0, playbackStart = 0, playbackSceneStart = 0, playbackIndex = 0;
let selectedAction = 'idle';
let projectData = loadProject() || {movieName:'जंगल का नया दोस्त',scenes};
function loadProject(){try{return JSON.parse(localStorage.getItem('mdAnimationStudioProject')||'null')}catch{return null}}
function persist(){projectData={movieName:$('movieName').value,scenes};localStorage.setItem('mdAnimationStudioProject',JSON.stringify(projectData));}
$('movieName').value=projectData.movieName || 'जंगल का नया दोस्त';

const viewport=$('viewport');
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,preserveDrawingBuffer:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;
viewport.innerHTML='';viewport.appendChild(renderer.domElement);
const world=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(42,1,.1,120);
camera.position.set(5,4.3,8);
const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(0,1.25,0);controls.enableDamping=true;controls.dampingFactor=.06;
world.add(new THREE.HemisphereLight(0xffffff,0x62704b,2.0));
const keyLight=new THREE.DirectionalLight(0xffe9c8,3.1);keyLight.position.set(-5,10,7);keyLight.castShadow=true;keyLight.shadow.mapSize.set(1024,1024);world.add(keyLight);
const fillLight=new THREE.DirectionalLight(0xb9d8ff,.8);fillLight.position.set(5,4,-5);world.add(fillLight);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(100,100),new THREE.MeshStandardMaterial({color:0x6d9a50,roughness:1}));
ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;world.add(ground);
const grid=new THREE.GridHelper(40,40,0x5d8052,0x8eae77);grid.position.y=.012;world.add(grid);
const environmentGroup=new THREE.Group();world.add(environmentGroup);
const actorGroup=new THREE.Group();world.add(actorGroup);

function material(color,roughness=.82){return new THREE.MeshStandardMaterial({color,roughness});}
function ball(parent,name,color,pos,scale){const m=new THREE.Mesh(new THREE.SphereGeometry(1,24,18),material(color));m.name=name;m.position.set(...pos);m.scale.set(...scale);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
function capsuleLimb(parent,name,color,pos,r=.13,len=.5){const g=new THREE.Group();g.name=name;g.position.set(...pos);parent.add(g);const mesh=new THREE.Mesh(new THREE.CapsuleGeometry(r,len,5,10),material(color));mesh.position.y=-len*.38;mesh.castShadow=true;g.add(mesh);return g;}
function makeLion(){
 const g=new THREE.Group();g.name='Lion';
 const body=ball(g,'body',0xc98334,[0,1.08,0],[.72,.53,1.02]);
 ball(g,'mane',0x82401e,[0,1.57,.68],[.76,.78,.52]);
 const head=ball(g,'head',0xe3a24b,[0,1.72,1.03],[.47,.47,.43]);
 ball(g,'muzzle',0xf0d2a1,[0,1.52,1.38],[.31,.2,.2]);const mouth=ball(g,'mouth',0x3a1713,[0,1.405,1.61],[.10,.025,.025]);ball(g,'nose',0x30201b,[0,1.64,1.56],[.105,.075,.07]);
 for(const x of [-.27,.27]){ball(g,'ear',0x994f27,[x,2.08,.96],[.15,.17,.12]);ball(g,'eye',0x1b1510,[x*.75,1.82,1.405],[.05,.06,.035]);}
 const legs=[];for(const x of [-.45,.45])for(const z of [-.62,.57])legs.push(capsuleLimb(g,'leg',0xc98334,[x,.75,z],.14,.5));
 const tail=new THREE.Group();tail.position.set(0,1.3,-.9);g.add(tail);const tube=new THREE.Mesh(new THREE.CylinderGeometry(.045,.07,.85,10),material(0xc98334));tube.rotation.x=Math.PI/2.4;tube.position.z=-.34;tail.add(tube);ball(tail,'tailTip',0x3b2018,[0,-.08,-.72],[.12,.12,.15]);
 g.userData={legs,tail,body,head,mouth};return g;
}
function makeRabbit(){
 const g=new THREE.Group();g.name='Rabbit';const body=ball(g,'body',0xe9e5df,[0,.94,0],[.5,.58,.64]);const head=ball(g,'head',0xf4f0e9,[0,1.61,.48],[.42,.42,.39]);
 for(const x of [-.2,.2]){const ear=ball(g,'ear',0xf4f0e9,[x,2.17,.43],[.12,.45,.11]);ear.rotation.z=x<0?-.12:.12;ball(g,'innerEar',0xe99ba6,[x,2.18,.53],[.065,.33,.025]);ball(g,'eye',0x211b1b,[x*.7,1.69,.82],[.043,.055,.03]);}
 ball(g,'nose',0xe78c9b,[0,1.48,.84],[.075,.055,.05]);const mouth=ball(g,'mouth',0x8e4550,[0,1.405,.91],[.075,.018,.02]);ball(g,'tail',0xffffff,[0,.82,-.61],[.18,.18,.18]);
 const legs=[];for(const x of [-.3,.3])for(const z of [-.34,.36])legs.push(capsuleLimb(g,'leg',0xe9e5df,[x,.56,z],.12,.38));
 g.userData={legs,body,head,mouth};return g;
}
function makeHuman(){
 const g=new THREE.Group();g.name='Human';const body=ball(g,'body',0x367ac0,[0,1.1,0],[.43,.65,.3]);const head=ball(g,'head',0xe7b18e,[0,1.95,.05],[.36,.39,.34]);ball(g,'hair',0x30231d,[0,2.18,-.01],[.37,.2,.34]);
 ball(g,'eye',0x211b1b,[-.12,1.98,.35],[.035,.045,.025]);ball(g,'eye',0x211b1b,[.12,1.98,.35],[.035,.045,.025]);const mouth=ball(g,'mouth',0x63372e,[0,1.82,.43],[.07,.018,.02]);
 const legs=[capsuleLimb(g,'leg',0x263c65,[-.2,.52,0],.13,.46),capsuleLimb(g,'leg',0x263c65,[.2,.52,0],.13,.46)];
 const arms=[capsuleLimb(g,'arm',0xe7b18e,[-.5,1.38,0],.1,.48),capsuleLimb(g,'arm',0xe7b18e,[.5,1.38,0],.1,.48)];
 g.userData={legs,arms,body,head,mouth};return g;
}
function addTree(parent,x,z,scale=1){
 const t=new THREE.Group();t.position.set(x,0,z);const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.13*scale,.2*scale,1.4*scale,9),material(0x76502e));trunk.position.y=.7*scale;trunk.castShadow=true;t.add(trunk);
 for(let i=0;i<3;i++){const c=new THREE.Mesh(new THREE.ConeGeometry((.95-i*.12)*scale,1.65*scale,9),material(i===1?0x397247:0x4b8550));c.position.y=(1.55+i*.42)*scale;c.castShadow=true;t.add(c);}parent.add(t);
}
function setEnvironment(kind){
 while(environmentGroup.children.length) {const o=environmentGroup.children.pop();o.traverse?.(x=>{x.geometry?.dispose();if(x.material&&!Array.isArray(x.material))x.material.dispose();});}
 let bg=0x9bc8e6,groundColor=0x6d9a50,fogColor=0x9bc8e6;
 if(kind==='meadow'){bg=0xa8d6ef;groundColor=0x86ad55;fogColor=0xa8d6ef;}
 if(kind==='night'){bg=0x111a35;groundColor=0x263d35;fogColor=0x18223b;}
 world.background=new THREE.Color(bg);world.fog=new THREE.Fog(fogColor,18,42);ground.material.color.setHex(groundColor);
 if(kind==='forest'){[[-5,-3,1.2],[4,-4,1.35],[-4,4,1],[5,3,1.1],[-7,0,.9],[7,0,.9]].forEach(a=>addTree(environmentGroup,...a));}
 if(kind==='meadow'){for(let i=0;i<18;i++){const x=(Math.random()-.5)*18,z=(Math.random()-.5)*15;const f=new THREE.Mesh(new THREE.SphereGeometry(.13,8,8),material(i%2?0xffd36a:0xe8a0b0));f.position.set(x,.18,z);f.scale.set(1,.55,1);environmentGroup.add(f);}}
 if(kind==='night'){const moon=new THREE.Mesh(new THREE.SphereGeometry(.85,24,18),new THREE.MeshBasicMaterial({color:0xfff1c2}));moon.position.set(-5,7,-10);environmentGroup.add(moon);for(let i=0;i<45;i++){const star=new THREE.Mesh(new THREE.SphereGeometry(.035,6,6),new THREE.MeshBasicMaterial({color:0xffffff}));star.position.set((Math.random()-.5)*24,3+Math.random()*8,-7-Math.random()*12);environmentGroup.add(star);}}
}
setEnvironment('forest');

function clearActor(){while(actorGroup.children.length){const o=actorGroup.children[0];actorGroup.remove(o);}}
function buildActor(type){
 clearActor();let obj=type==='rabbit'?makeRabbit():type==='human'?makeHuman():type==='custom'&&importedObject?importedObject:makeLion();
 if(type==='custom'&&!importedObject){obj=makeLion();toast('पहले GLB मॉडल इम्पोर्ट करें');}
 actorGroup.add(obj);actorObject=obj;return obj;
}
function animateActor(obj,action,t,mouthLevel=0){
 if(!obj)return;const u=obj.userData||{},legs=u.legs||[],arms=u.arms||[];
 const moving=action==='walk'||action==='run',speed=action==='run'?12:7;
 legs.forEach((l,i)=>l.rotation.x=moving?Math.sin(t*speed+i*Math.PI)*.62:action==='jump'?Math.sin(t*5+i)*.15:0);
 arms.forEach((l,i)=>{l.rotation.z=action==='wave'?(i===1?Math.sin(t*8)*.8:0):action==='talk'?Math.sin(t*6+i)*.22:0;l.rotation.x=action==='run'?Math.sin(t*speed+i*Math.PI)*.45:0;});
 if(u.body)u.body.position.y=(u.body.name==='body'?1.08:1.1)+(action==='jump'?Math.abs(Math.sin(t*5))*.65:Math.sin(t*3)*.025);
 if(u.head)u.head.rotation.x=action==='talk'?Math.sin(t*7)*.07:action==='roar'?Math.sin(t*5)*.18:0;
 if(u.tail)u.tail.rotation.y=Math.sin(t*4)*.28;
 if(u.mouth){const open=mouthLevel>0?mouthLevel:(action==='talk'?Math.abs(Math.sin(t*7))*.65:action==='roar'?Math.abs(Math.sin(t*5))*.8:0);u.mouth.scale.y=.018+open*.11;}
 obj.position.x=moving?Math.sin(t*(action==='run'?1.5:.65))*.65:0;
 obj.rotation.y=action==='roar'?Math.sin(t*2)*.12:0;
}
function cameraPreset(kind){
 const p={wide:[5,4.3,8],medium:[3.2,2.7,5.2],close:[1.5,2.25,3.1],low:[4,1.5,7]}[kind]||[5,4.3,8];
 camera.position.set(...p);controls.target.set(0,1.2,0);controls.update();
}
function applySceneEnvironment(){setEnvironment(scenes[current]?.environment||'forest');}
function renderTimeline(){
 const el=$('timeline');el.innerHTML='';
 scenes.forEach((s,i)=>{
  const card=document.createElement('button');card.className='timeline-card'+(i===current?' selected':'');
  const actorName={lion:'🦁 शेर',rabbit:'🐰 खरगोश',human:'🧍 इंसान',custom:'📦 मॉडल'}[s.actor]||s.actor;
  card.innerHTML=`<span class="clip-number">SCENE ${i+1}</span><b>${esc(s.name||'सीन '+(i+1))}</b><small>${actorName} · ${esc(s.action)} · ${s.duration}s</small><span class="clip-line"><i style="width:${Math.min(100,Math.max(12,s.duration*7))}%"></i></span>`;
  card.onclick=()=>selectScene(i);el.appendChild(card);
 });
 $('sceneSummary').textContent=`${scenes.length} सीन`;
 $('totalDuration').textContent=`कुल अवधि: ${scenes.reduce((a,s)=>a+(Number(s.duration)||1),0)} सेकंड`;
}
function selectScene(i){
 current=Math.max(0,Math.min(i,scenes.length-1));const s=scenes[current];
 $('sceneName').value=s.name||'';$('sceneDescription').value=s.description||'';$('dialogueInput').value=s.dialogue||'';
 $('actorSelect').value=s.actor;$('actionSelect').value=s.action;$('durationInput').value=s.duration;
 $('environmentSelect').value=s.environment||'forest';$('cameraSelect').value=s.camera||'wide';$('cameraMove').value=s.cameraMove||'static';
 $('selectedSceneTag').textContent='SCENE '+(current+1);$('viewStatus').textContent=`सीन ${current+1} · ${s.name}`;
 document.querySelectorAll('.character').forEach(b=>b.classList.toggle('active',b.dataset.actor===s.actor));
 buildActor(s.actor);selectedAction=s.action;applySceneEnvironment();cameraPreset(s.camera||'wide');renderTimeline();
}
function applyEditor(){
 const s=scenes[current];if(!s)return;
 s.name=$('sceneName').value.trim()||`सीन ${current+1}`;s.description=$('sceneDescription').value;s.dialogue=$('dialogueInput').value.trim();
 s.actor=$('actorSelect').value;s.action=$('actionSelect').value;s.duration=Math.max(1,Math.min(60,Number($('durationInput').value)||6));
 s.environment=$('environmentSelect').value;s.camera=$('cameraSelect').value;s.cameraMove=$('cameraMove').value;
 selectedAction=s.action;buildActor(s.actor);applySceneEnvironment();cameraPreset(s.camera);renderTimeline();persist();toast('सीन अपडेट हो गया');
}
function addScene(scene){
 scenes.push(scene||{id:uid(),name:`सीन ${scenes.length+1}`,actor:scenes[current]?.actor||'lion',action:'walk',duration:5,description:'नया दृश्य',environment:scenes[current]?.environment||'forest',camera:'wide',cameraMove:'static'});
 selectScene(scenes.length-1);persist();
}
function sentenceToScene(sentence,index){
 const t=sentence.toLowerCase();let actor='lion',action='idle';
 if(/खरगोश|rabbit|ससा/.test(t))actor='rabbit';else if(/इंसान|लड़का|लड़की|आदमी|महिला|व्यक्ति/.test(t))actor='human';
 if(/दौड़|भाग/.test(t))action='run';else if(/चल|आया|गया|जाता|आती|आगे बढ़/.test(t))action='walk';else if(/कूद|छलांग/.test(t))action='jump';else if(/हाथ|नमस्ते|अभिवादन|हिलाया/.test(t))action='wave';else if(/बोला|कहा|बात|पूछा|उत्तर/.test(t))action='talk';else if(/दहाड़|गर्जना|गुस्सा/.test(t))action='roar';
 return {id:uid(),name:`सीन ${index+1}`,actor,action,duration:5,description:sentence.trim(),dialogue:'',environment:'forest',camera:'wide',cameraMove:'static'};
}
function buildStory(){
 const raw=$('storyInput').value.trim();if(!raw){toast('पहले कहानी लिखें');return;}
 const sentences=raw.split(/[।.!?\\n]+/).map(x=>x.trim()).filter(Boolean);
 if(!sentences.length){toast('कहानी में वाक्य नहीं मिले');return;}
 scenes=sentences.slice(0,30).map(sentenceToScene);selectScene(0);persist();toast(`${scenes.length} सीन बनाए गए`);
}
function resize(){
 const w=Math.max(280,viewport.clientWidth),h=Math.max(240,viewport.clientHeight);
 renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(viewport);resize();

$('cameraHome').onclick=()=>cameraPreset('wide');$('cameraFront').onclick=()=>{camera.position.set(0,2.7,8);controls.target.set(0,1.2,0);controls.update();};$('cameraWide').onclick=()=>cameraPreset('wide');
document.querySelectorAll('.character[data-actor]').forEach(b=>b.onclick=()=>{$('actorSelect').value=b.dataset.actor;applyEditor();});
$('importModel').onclick=()=>$('modelFile').click();
$('modelFile').onchange=async e=>{
 const file=e.target.files?.[0];if(!file)return;
 try{const url=URL.createObjectURL(file);const loader=new GLTFLoader();loader.load(url,gltf=>{importedObject=gltf.scene;importedObject.scale.setScalar(1);importedObject.position.set(0,0,0);importedUrl=url;$('actorSelect').value='custom';applyEditor();toast('3D मॉडल इम्पोर्ट हो गया');},undefined,err=>{console.error(err);toast('मॉडल नहीं खुल सका');});}catch(err){toast('मॉडल इम्पोर्ट विफल');}
 e.target.value='';
};
$('applyScene').onclick=applyEditor;$('addScene').onclick=()=>addScene();
$('duplicateScene').onclick=()=>{const copy=JSON.parse(JSON.stringify(scenes[current]));copy.id=uid();copy.name=(copy.name||'सीन')+' कॉपी';scenes.splice(current+1,0,copy);selectScene(current+1);persist();};
$('deleteScene').onclick=()=>{if(scenes.length===1){toast('कम से कम एक सीन जरूरी है');return;}scenes.splice(current,1);selectScene(Math.max(0,current-1));persist();};
$('storyBuild').onclick=buildStory;
$('saveProject').onclick=()=>{persist();toast('प्रोजेक्ट इस डिवाइस में सेव हो गया');};
$('movieName').onchange=persist;
$('backupBtn').onclick=()=>{persist();const blob=new Blob([JSON.stringify(projectData,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(($('movieName').value||'md-movie').replace(/[^a-z0-9अ-ह]/gi,'-'))+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000);};
$('restoreBtn').onclick=()=>$('restoreFile').click();
$('restoreFile').onchange=async e=>{const f=e.target.files?.[0];if(!f)return;try{const d=JSON.parse(await f.text());if(!Array.isArray(d.scenes)||!d.scenes.length)throw Error('bad');scenes=d.scenes; $('movieName').value=d.movieName||'मेरी मूवी';selectScene(0);persist();toast('प्रोजेक्ट लोड हो गया');}catch{toast('यह JSON प्रोजेक्ट फाइल नहीं है');}e.target.value='';};

let lastFrame=performance.now();
function renderFrame(now){
 requestAnimationFrame(renderFrame);
 const dt=Math.min(.05,(now-lastFrame)/1000);lastFrame=now;animationClock+=dt;
 if(moviePlaying){
  const elapsed=(now-playbackStart)/1000;
  let acc=0,idx=0;
  for(;idx<scenes.length;idx++){if(elapsed<acc+Number(scenes[idx].duration)){break;}acc+=Number(scenes[idx].duration);}
  if(idx>=scenes.length){moviePlaying=false;$('playMovie').textContent='▶ पूरी मूवी चलाएँ';idx=scenes.length-1;}
  if(idx!==current){selectScene(idx);playbackSceneStart=acc;}
  const s=scenes[current];animateActor(actorObject,s.action,elapsed-playbackSceneStart);
  if(s.cameraMove==='pan'){camera.position.x=5+Math.sin(elapsed*.35)*1.2;controls.target.x=Math.sin(elapsed*.35)*.5;}
  else if(s.cameraMove==='orbit'){camera.position.x=Math.sin(elapsed*.45)*7;camera.position.z=Math.cos(elapsed*.45)*7;camera.lookAt(0,1.2,0);}
 } else {animateActor(actorObject,selectedAction,animationClock);}
 controls.update();renderer.render(world,camera);
}
requestAnimationFrame(renderFrame);
$('playMovie').onclick=()=>{
 if(moviePlaying){moviePlaying=false;$('playMovie').textContent='▶ पूरी मूवी चलाएँ';return;}
 applyEditor();moviePlaying=true;playbackStart=performance.now();playbackSceneStart=0;$('playMovie').textContent='Ⅱ रोकें';
};

const audioAssets=[];
let audioContext=null;
function getAudioContext(){if(!audioContext)audioContext=new (window.AudioContext||window.webkitAudioContext)();return audioContext;}
function renderAudioTracks(){
 const el=$('audioTrackList');if(!audioAssets.length){el.innerHTML='<small>अभी कोई ऑडियो ट्रैक नहीं जोड़ा गया।</small>';return;}
 el.innerHTML='';
 audioAssets.forEach((a,i)=>{
  const row=document.createElement('div');row.className='audio-track';
  row.innerHTML=`<span>${a.kind==='music'?'♫':'🎙'} ${esc(a.name)}</span><label class="track-control">वॉल्यूम <input data-volume="${i}" type="range" min="0" max="1.5" step="0.05" value="${a.volume}"></label><label class="track-control">शुरुआत (सेकंड) <input data-offset="${i}" type="number" min="0" max="600" step="0.5" value="${a.offset}"></label><small>${a.duration.toFixed(1)}s</small><button data-remove="${i}">हटाएँ</button>`;
  row.querySelector('button').onclick=()=>{audioAssets.splice(i,1);renderAudioTracks();};
  row.querySelector('[data-volume]').onchange=e=>{audioAssets[i].volume=Number(e.target.value);};
  row.querySelector('[data-offset]').onchange=e=>{audioAssets[i].offset=Math.max(0,Number(e.target.value)||0);};el.appendChild(row);
 });
}
$('audioFileInput').onchange=async e=>{
 const files=[...(e.target.files||[])];const ctx=getAudioContext();
 for(const f of files){try{const buf=await ctx.decodeAudioData(await f.arrayBuffer());audioAssets.push({name:f.name,buffer:buf,kind:'music',volume:1,offset:0,duration:buf.duration});}catch(err){toast('ऑडियो फाइल नहीं खुली: '+f.name);}}
 renderAudioTracks();e.target.value='';
};
$('saveDialogue').onclick=()=>{scenes[current].dialogue=$('dialogueInput').value.trim();persist();toast('डायलॉग सीन में सेव हो गया');};
function base64ToArrayBuffer(b64){const bin=atob(b64);const bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);return bytes.buffer;}
async function createNativeTts(text){
 const result=await NativeMovieExporter.synthesizeDialogue({text,language:'hi-IN'});
 const ctx=getAudioContext();return await ctx.decodeAudioData(base64ToArrayBuffer(result.wavBase64));
}
$('previewTts').onclick=async()=>{
 const text=$('dialogueInput').value.trim();if(!text){toast('पहले संवाद लिखें');return;}
 try{toast('फोन की हिंदी आवाज़ तैयार हो रही है');const b=await createNativeTts(text);const src=getAudioContext().createBufferSource();src.buffer=b;const gain=getAudioContext().createGain();gain.gain.value=Number($('dialogueVolume').value);src.connect(gain).connect(getAudioContext().destination);src.start();}catch(e){console.error(e);toast('Native TTS उपलब्ध नहीं: हिंदी voice pack जाँचें');}
};
function makePcmChunk(globalTime,frameSamples,sampleRate,dialogueTracks,musicTracks){
 const out=new Int16Array(frameSamples);let sumSq=0;
 const dVol=Number($('dialogueVolume').value),mVol=Number($('musicVolume').value);
 for(let i=0;i<frameSamples;i++){
  const t=globalTime+i/sampleRate;let sample=0,dialogue=0;
  for(const a of dialogueTracks){const local=t-a.offset;if(local<0||local>=a.buffer.duration)continue;const ch=a.buffer.getChannelData(0);const idx=Math.floor(local*a.buffer.sampleRate);if(idx<ch.length)dialogue+=ch[idx]*dVol*(a.volume??1);}
  for(const a of musicTracks){const local=t-a.offset;if(local<0||local>=a.buffer.duration)continue;const ch=a.buffer.getChannelData(0);const idx=Math.floor(local*a.buffer.sampleRate);if(idx<ch.length)sample+=ch[idx]*mVol*(a.volume??1);}
  const mixed=Math.max(-1,Math.min(1,dialogue+sample));out[i]=mixed<0?mixed*32768:mixed*32767;sumSq+=dialogue*dialogue;
 }
 return {pcm:bytesToBase64(new Uint8Array(out.buffer)),mouth:Math.min(1,Math.sqrt(sumSq/frameSamples)*3.8)};
}
function bytesToBase64(bytes){let binary='';const step=0x8000;for(let i=0;i<bytes.length;i+=step)binary+=String.fromCharCode(...bytes.subarray(i,i+step));return btoa(binary);}
function canvasJpegBase64(){return renderer.domElement.toDataURL('image/jpeg',.82).split(',')[1];}
async function exportMovie(){
 if(recording)return;
 if(!NativeMovieExporter){toast('Native Android MP4 plugin उपलब्ध नहीं');return;}
 recording=true;moviePlaying=false;
 const originalScene=current,aspect=$('aspectSelect').value,quality=Number($('qualitySelect').value);
 const fps=30,sampleRate=44100,frameSamples=Math.round(sampleRate/fps);
 const height=quality,width=aspect==='portrait'?height:aspect==='square'?height:Math.round(height*16/9),outputHeight=aspect==='portrait'?Math.round(height*16/9):height;
 $('exportProgress').hidden=false;$('videoDownload').hidden=true;$('progressBar').style.width='0%';
 const totalDuration=scenes.reduce((a,s)=>a+Math.max(1,Number(s.duration)||1),0);
 const totalFrames=Math.ceil(totalDuration*fps);
 const dialogueTracks=[];const musicTracks=audioAssets.map(a=>({...a,offset:Number(a.offset)||0}));
 try{
  for(let i=0,offset=0;i<scenes.length;i++){
   const sc=scenes[i];if(sc.dialogue?.trim()){
    $('progressText').textContent=`सीन ${i+1}: डायलॉग आवाज़ तैयार हो रही है`;
    const buffer=await createNativeTts(sc.dialogue);
    dialogueTracks.push({name:'Dialogue '+(i+1),buffer,kind:'dialogue',volume:1,offset,duration:buffer.duration});
   }
   offset+=Math.max(1,Number(sc.duration)||1);
  }
  $('progressText').textContent='Native MP4 इंजन शुरू हो रहा है…';
  const init=await NativeMovieExporter.startExport({width,height:outputHeight,fps,sampleRate,channels:1,displayName:($('movieName').value||'MD-Animation-Movie').replace(/[^a-z0-9-_]/gi,'-')+'.mp4'});
  const oldTarget=controls.target.clone();const oldCam=camera.position.clone();
  renderer.setSize(width,outputHeight,false);camera.aspect=width/outputHeight;camera.updateProjectionMatrix();
  let globalFrame=0,elapsed=0;
  for(let si=0;si<scenes.length;si++){
   const sc=scenes[si];selectScene(si);const count=Math.ceil(Math.max(1,Number(sc.duration)||1)*fps);
   for(let fi=0;fi<count;fi++){
    const local=fi/fps,globalTime=globalFrame/fps;
    const audio=makePcmChunk(globalTime,frameSamples,sampleRate,dialogueTracks,musicTracks);
    animateActor(actorObject,sc.action,local,audio.mouth);
    if(sc.cameraMove==='pan'){camera.position.x=5+Math.sin(local*.35)*1.2;controls.target.x=Math.sin(local*.35)*.5;}
    else if(sc.cameraMove==='orbit'){camera.position.x=Math.sin(local*.45)*7;camera.position.z=Math.cos(local*.45)*7;camera.lookAt(0,1.2,0);}
    else cameraPreset(sc.camera||'wide');
    controls.update();renderer.render(world,camera);
    const jpeg=canvasJpegBase64();
    await NativeMovieExporter.addFrame({jpegBase64:jpeg,pcmBase64:audio.pcm});
    globalFrame++;
    const pct=Math.min(100,globalFrame/totalFrames*100);$('progressBar').style.width=pct+'%';
    $('progressText').textContent=`Native MP4 रेंडर: सीन ${si+1}/${scenes.length} · ${Math.round(pct)}%`;
   }
   elapsed+=count/fps;
  }
  $('progressText').textContent='MP4 फाइल फाइनल की जा रही है…';
  const result=await NativeMovieExporter.finishExport();
  const link=$('videoDownload');link.hidden=false;link.removeAttribute('href');link.textContent='✓ MP4 गैलरी में सेव हो गया';link.onclick=(ev)=>{ev.preventDefault();toast('MP4 आपके Movies/MD Animation Studio फोल्डर में सेव है');};
  $('progressBar').style.width='100%';$('progressText').textContent=`पूरा हुआ · ${result.displayName||'MP4'}`;
  toast('MP4 वीडियो गैलरी में सेव हो गया');
  controls.target.copy(oldTarget);camera.position.copy(oldCam);controls.update();
 }catch(e){console.error(e);$('progressText').textContent='एक्सपोर्ट विफल: '+(e.message||'Unknown error');toast('MP4 एक्सपोर्ट में समस्या — लॉग देखें');try{await NativeMovieExporter.cancelExport();}catch{}}
 finally{renderer.setSize(viewport.clientWidth,viewport.clientHeight,false);camera.aspect=viewport.clientWidth/viewport.clientHeight;camera.updateProjectionMatrix();recording=false;selectScene(originalScene);}
}
$('exportBtn').onclick=exportMovie;
$('helpBtn').onclick=()=>alert('यह coding-based 3D movie maker है। कहानी से सीन बनाइए, हर सीन में कैरेक्टर और एक्शन चुनिए, फिर पूरी मूवी चलाकर देखें या Native MP4 वीडियो एक्सपोर्ट करें। इसमें डायलॉग, लिप-सिंक और म्यूजिक मिक्सर भी उपलब्ध हैं।');

selectScene(0);
persist();
